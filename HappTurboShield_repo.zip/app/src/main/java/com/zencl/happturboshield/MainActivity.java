package com.zencl.happturboshield;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(9, 11, 20);
    private final int card = Color.rgb(20, 24, 40);
    private final int accent = Color.rgb(167, 139, 250);
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView status, ping, loss, dns, network, log;
    private EditText hostInput, portInput;
    private Button testButton;
    private volatile boolean running = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        root.setBackgroundColor(bg);
        scroll.addView(root);

        TextView title = text("HAPP TURBO", 27, Color.WHITE, true);
        root.addView(title);
        TextView subtitle = text("TURBO  ×  SHIELD  •  Network diagnostics", 13, accent, false);
        LinearLayout.LayoutParams sp = params(-1, -2); sp.topMargin = dp(5); root.addView(subtitle, sp);

        status = text("●  READY", 15, Color.rgb(110, 231, 183), true);
        addCard(root, status);

        LinearLayout inputs = new LinearLayout(this);
        inputs.setOrientation(LinearLayout.HORIZONTAL);
        hostInput = edit("Host (e.g. 1.1.1.1)", "1.1.1.1", 1);
        portInput = edit("Port", "443", 0);
        inputs.addView(hostInput, new LinearLayout.LayoutParams(0, dp(52), 2));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, dp(52), 1); pp.leftMargin = dp(8);
        inputs.addView(portInput, pp);
        LinearLayout.LayoutParams ip = params(-1, -2); ip.topMargin = dp(14); root.addView(inputs, ip);

        testButton = new Button(this);
        testButton.setText("⚡  TEST CONNECTION");
        testButton.setTextColor(Color.WHITE);
        testButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(109, 75, 220)));
        LinearLayout.LayoutParams bp = params(-1, dp(54)); bp.topMargin = dp(12); root.addView(testButton, bp);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        ping = text("— ms\nLATENCY", 19, Color.WHITE, true);
        loss = text("— %\nFAILED TESTS", 16, Color.WHITE, true);
        stats.addView(statCard(ping), new LinearLayout.LayoutParams(0, dp(88), 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(88), 1); lp.leftMargin = dp(10);
        stats.addView(statCard(loss), lp);
        LinearLayout.LayoutParams stp = params(-1, -2); stp.topMargin = dp(12); root.addView(stats, stp);

        dns = text("DNS CHECK\nNot tested", 15, Color.WHITE, false);
        addCard(root, dns);
        network = text("SHIELD STATUS\nChecking network…", 15, Color.WHITE, false);
        addCard(root, network);
        log = text("DIAGNOSTICS LOG\nReady. No traffic is routed through this app.", 13, Color.LTGRAY, false);
        addCard(root, log);

        TextView note = text("Prototype: measures reachability to the host you enter. It does not modify Happ, create a VPN tunnel, or guarantee leak protection.", 12, Color.rgb(170, 176, 196), false);
        LinearLayout.LayoutParams np = params(-1, -2); np.topMargin = dp(14); root.addView(note, np);

        setContentView(scroll);
        refreshNetworkStatus();
        testButton.setOnClickListener(v -> runTest());
    }

    private void runTest() {
        if (running) return;
        final String host = hostInput.getText().toString().trim();
        final int port;
        try { port = Integer.parseInt(portInput.getText().toString().trim()); }
        catch (Exception e) { portInput.setError("Use port 1–65535"); return; }
        if (host.isEmpty() || port < 1 || port > 65535) { hostInput.setError("Enter a host"); return; }

        running = true;
        testButton.setEnabled(false);
        status.setText("●  TESTING…");
        log.setText("DIAGNOSTICS LOG\nTesting " + host + ":" + port + " (5 attempts)…");
        worker.execute(() -> {
            long[] times = new long[5];
            int ok = 0;
            String err = "";
            for (int i = 0; i < 5; i++) {
                long start = System.nanoTime();
                try (Socket s = new Socket()) {
                    s.connect(new InetSocketAddress(host, port), 2500);
                    times[ok++] = (System.nanoTime() - start) / 1_000_000L;
                } catch (Exception ex) { err = ex.getClass().getSimpleName(); }
            }
            long avg = -1;
            if (ok > 0) {
                long sum = 0; for (int i=0;i<ok;i++) sum += times[i];
                avg = sum / ok;
            }
            final long result = avg;
            final int successes = ok;
            final String error = err;
            runOnUiThread(() -> {
                running = false;
                testButton.setEnabled(true);
                if (result >= 0) {
                    ping.setText(result + " ms\nTCP LATENCY");
                    status.setText(successes == 5 ? "●  REACHABLE" : "●  UNSTABLE");
                    status.setTextColor(successes == 5 ? Color.rgb(110,231,183) : Color.rgb(251,191,36));
                } else {
                    ping.setText("TIMEOUT\nTCP LATENCY");
                    status.setText("●  UNREACHABLE");
                    status.setTextColor(Color.rgb(248,113,113));
                }
                loss.setText(String.format(Locale.US, "%.0f %%\nFAILED TESTS", (5-successes)*20.0));
                log.setText("DIAGNOSTICS LOG\nHost: " + host + ":" + port +
                    "\nSuccessful attempts: " + successes + "/5" +
                    "\nAverage TCP connect time: " + (result >= 0 ? result + " ms" : "unavailable") +
                    (error.isEmpty() ? "" : "\nLast error: " + error) +
                    "\n\nThis is TCP connection time, not ICMP ping and not a full speed test.");
            });
        });
    }

    private void refreshNetworkStatus() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
            boolean connected = c != null && (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    || c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
            network.setText("SHIELD STATUS\nNetwork: " + (connected ? "connected" : "offline/unknown") +
                    "\nVPN transport: " + (c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ? "detected" : "not detected") +
                    "\n\nVPN detection is informational only; this prototype does not block traffic if VPN disconnects.");
            dns.setText("DNS CHECK\nTap TEST CONNECTION to test host resolution and TCP reachability.");
        } catch (Exception e) {
            network.setText("SHIELD STATUS\nUnable to read network state.");
        }
    }

    private EditText edit(String hint, String value, int inputType) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setText(value); e.setHint(hint); e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY); e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        e.setInputType(inputType == 0 ? 2 :  textInputType());
        return e;
    }
    private int textInputType() { return 1; }
    private void addCard(LinearLayout root, View child) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(15), dp(14), dp(15), dp(14));
        box.setBackgroundTintList(android.content.res.ColorStateList.valueOf(card));
        box.setBackgroundColor(card);
        LinearLayout.LayoutParams p = params(-1, -2); p.topMargin = dp(12);
        box.addView(child); root.addView(box, p);
    }
    private View statCard(View child) {
        LinearLayout box = new LinearLayout(this); box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(card); box.addView(child); return box;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        super.onDestroy();
        worker.shutdownNow();
    }
}
