# Как получить APK через GitHub Actions с телефона

1. Создайте новый пустой репозиторий на GitHub.
2. Распакуйте `HappTurboShield_source.zip` и загрузите **содержимое** папки `HappTurboShield` в корень репозитория (включая скрытую папку `.github`).
3. Откройте вкладку **Actions** и выберите **Build Android APK**.
4. Нажмите **Run workflow**. Дождитесь зелёной галочки.
5. Откройте завершённый запуск и скачайте artifact **HappTurboShield-debug-apk**.
6. Распакуйте скачанный artifact ZIP — внутри будет `app-debug.apk`.

APK будет отладочным и подписан debug-ключом. Это прототип диагностики, не встроенный в Happ VPN.
